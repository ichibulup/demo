﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.Data.SqlClient;
using CRUDAjax.Models;

namespace CRUDAjax.Controllers
{
    // public class HomeController : Controller
    // {
    //     EmployeeDB empDB = new EmployeeDB();
    //     // GET: Home
    //     public ActionResult Index()
    //     {
    //         return View();
    //     }
    //     public JsonResult List()
    //     {
    //         return Json(empDB.ListAll(),JsonRequestBehavior.AllowGet);
    //     }
    //     public JsonResult Add(Employee emp)
    //     {
    //         return Json(empDB.Add(emp), JsonRequestBehavior.AllowGet);
    //     }
    //     public JsonResult GetbyID(int ID)
    //     {
    //         var Employee = empDB.ListAll().Find(x => x.EmployeeID.Equals(ID));
    //         return Json(Employee, JsonRequestBehavior.AllowGet);
    //     }
    //     public JsonResult Update(Employee emp)
    //     {
    //         return Json(empDB.Update(emp), JsonRequestBehavior.AllowGet);
    //     }
    //     public JsonResult Delete(int ID)
    //     {
    //         return Json(empDB.Delete(ID), JsonRequestBehavior.AllowGet);
    //     }
    // }

    // public class HomeController : Controller
    // {
    //     private readonly string connectionString = "your_connection_string_here";

    //     // Function to Load Data
    //     public ActionResult Load()
    //     {
    //         List<Employee> employees = new List<Employee>();

    //         using (SqlConnection conn = new SqlConnection(connectionString))
    //         {
    //             string query = "SELECT * FROM Employee";
    //             SqlCommand cmd = new SqlCommand(query, conn);
    //             conn.Open();
    //             SqlDataReader reader = cmd.ExecuteReader();

    //             while (reader.Read())
    //             {
    //                 employees.Add(new Employee
    //                 {
    //                     EmployeeID = (int)reader["EmployeeID"],
    //                     Name = reader["Name"].ToString(),
    //                     Age = (int)reader["Age"],
    //                     State = reader["State"].ToString(),
    //                     Country = reader["Country"].ToString()
    //                 });
    //             }
    //         }

    //         return Json(new { data = employees }, JsonRequestBehavior.AllowGet);
    //     }

    //     // Add Employee
    //     [HttpPost]
    //     public ActionResult Add(Employee employee)
    //     {
    //         using (SqlConnection conn = new SqlConnection(connectionString))
    //         {
    //             string query = "INSERT INTO Employee (Name, Age, State, Country) VALUES (@Name, @Age, @State, @Country)";
    //             SqlCommand cmd = new SqlCommand(query, conn);
    //             cmd.Parameters.AddWithValue("@Name", employee.Name);
    //             cmd.Parameters.AddWithValue("@Age", employee.Age);
    //             cmd.Parameters.AddWithValue("@State", employee.State);
    //             cmd.Parameters.AddWithValue("@Country", employee.Country);
    //             conn.Open();
    //             cmd.ExecuteNonQuery();
    //         }
    //         return Json(new { success = true });
    //     }

    //     // Update Employee
    //     [HttpPost]
    //     public ActionResult Update(Employee employee)
    //     {
    //         using (SqlConnection conn = new SqlConnection(connectionString))
    //         {
    //             string query = "UPDATE Employee SET Name = @Name, Age = @Age, State = @State, Country = @Country WHERE EmployeeID = @EmployeeID";
    //             SqlCommand cmd = new SqlCommand(query, conn);
    //             cmd.Parameters.AddWithValue("@EmployeeID", employee.EmployeeID);
    //             cmd.Parameters.AddWithValue("@Name", employee.Name);
    //             cmd.Parameters.AddWithValue("@Age", employee.Age);
    //             cmd.Parameters.AddWithValue("@State", employee.State);
    //             cmd.Parameters.AddWithValue("@Country", employee.Country);
    //             conn.Open();
    //             cmd.ExecuteNonQuery();
    //         }
    //         return Json(new { success = true });
    //     }

    //     // Delete Employee
    //     [HttpPost]
    //     public ActionResult Delete(int id)
    //     {
    //         using (SqlConnection conn = new SqlConnection(connectionString))
    //         {
    //             string query = "DELETE FROM Employee WHERE EmployeeID = @EmployeeID";
    //             SqlCommand cmd = new SqlCommand(query, conn);
    //             cmd.Parameters.AddWithValue("@EmployeeID", id);
    //             conn.Open();
    //             cmd.ExecuteNonQuery();
    //         }
    //         return Json(new { success = true });
    //     }

    //     // Search Employee
    //     [HttpGet]
    //     public ActionResult Search(string searchTerm)
    //     {
    //         List<Employee> employees = new List<Employee>();

    //         using (SqlConnection conn = new SqlConnection(connectionString))
    //         {
    //             string query = "SELECT * FROM Employee WHERE Name LIKE '%' + @searchTerm + '%' OR Country LIKE '%' + @searchTerm + '%'";
    //             SqlCommand cmd = new SqlCommand(query, conn);
    //             cmd.Parameters.AddWithValue("@searchTerm", searchTerm);
    //             conn.Open();
    //             SqlDataReader reader = cmd.ExecuteReader();

    //             while (reader.Read())
    //             {
    //                 employees.Add(new Employee
    //                 {
    //                     EmployeeID = (int)reader["EmployeeID"],
    //                     Name = reader["Name"].ToString(),
    //                     Age = (int)reader["Age"],
    //                     State = reader["State"].ToString(),
    //                     Country = reader["Country"].ToString()
    //                 });
    //             }
    //         }

    //         return Json(new { data = employees }, JsonRequestBehavior.AllowGet);
    //     }

    //     // Export Data to Excel (Placeholder)
    //     public ActionResult ExportToExcel()
    //     {
    //         // TODO: Add logic to export to Excel
    //         return Json(new { success = true });
    //     }

    //     // Export Data to Word (Placeholder)
    //     public ActionResult ExportToWord()
    //     {
    //         // TODO: Add logic to export to Word
    //         return Json(new { success = true });
    //     }
    // }
    public class HomeController : Controller
    {
        EmployeeDB empDB = new EmployeeDB();

        public ActionResult Index()
        {
            return View();
        }

        public JsonResult List()
        {
            // return Json(empDB.ListAll(), JsonRequestBehavior.AllowGet);
            try
            {
                return Json(empDB.ListAll(), JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult Add(Employee emp)
        {
            return Json(empDB.Add(emp), JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetbyID(int ID)
        {
            var employee = empDB.ListAll().Find(x => x.EmployeeID.Equals(ID));
            return Json(employee, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Update(Employee emp)
        {
            return Json(empDB.Update(emp), JsonRequestBehavior.AllowGet);
        }

        public JsonResult Delete(int ID)
        {
            return Json(empDB.Delete(ID), JsonRequestBehavior.AllowGet);
        }
    }
}